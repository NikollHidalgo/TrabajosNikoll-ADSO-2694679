/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import Interface.Conversion;

/**
 *
 * @author User
 */
public class Implementar implements Conversion{
    private static final double COL_PESO_EXCHANGE_RATE = 3865.0;
    private static final double DOLLAR_EXCHANGE_RATE = 0.00025;
    private static final double SOL_EXCHANGE_RATE = 0.27;
    private static final double PESETA_EXCHANGE_RATE = 0.0072;
    private static final double FRANC_EXCHANGE_RATE = 0.00028;

    @Override
    public double convertToColombianPesos(double bolivares) {
        return bolivares * COL_PESO_EXCHANGE_RATE;
    }

    @Override
    public double convertToDollars(double bolivares) {
        return bolivares * DOLLAR_EXCHANGE_RATE;
    }

    @Override
    public double convertToSoles(double bolivares) {
        return bolivares * SOL_EXCHANGE_RATE;
    }

    @Override
    public double convertToPesetas(double bolivares) {
        return bolivares * PESETA_EXCHANGE_RATE;
    }

    @Override
    public double convertToFrancs(double bolivares) {
        return bolivares * FRANC_EXCHANGE_RATE;
    }
    
}
