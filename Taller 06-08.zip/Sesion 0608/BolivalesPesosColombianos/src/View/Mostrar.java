/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;
import Interface.Conversion;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class Mostrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Conversion conversion;
        conversion = new Conversion() {
            @Override
            public double convertToColombianPesos(double bolivares) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToDollars(double bolivares) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToSoles(double bolivares) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToPesetas(double bolivares) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToFrancs(double bolivares) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };

        System.out.print("Ingrese la cantidad en bolívares: ");
        double bolivares = scanner.nextDouble();

        double pesos = conversion.convertToColombianPesos(bolivares);
        double dollars = conversion.convertToDollars(bolivares);
        double soles = conversion.convertToSoles(bolivares);
        double pesetas = conversion.convertToPesetas(bolivares);
        double francs = conversion.convertToFrancs(bolivares);

        System.out.println("Resultado de las conversiones:");
        System.out.println("Colombian Pesos: " + pesos);
        System.out.println("Dollars: " + dollars);
        System.out.println("Soles: " + soles);
        System.out.println("Pesetas: " + pesetas);
        System.out.println("Francs: " + francs);

        scanner.close();
    }
    }
    

