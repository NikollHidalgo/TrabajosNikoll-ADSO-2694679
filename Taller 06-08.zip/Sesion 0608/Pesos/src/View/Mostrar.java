/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;
import Interface.PesosInterface;
import java.util.Scanner;

/**
 *
 * @author Ambiente 209-2
 */
public class Mostrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        PesosInterface pesosInterface = null;
        Pesosinterface PesosInterface = new Pesosinterface();

        System.out.print("Ingrese la cantidad en pesos colombianos: ");
        double pesos = scanner.nextDouble();

        double dollars = pesosInterface.convertToDollars(pesos);
        double bolivares = pesosInterface.convertToBolivares(pesos);
        double soles = pesosInterface.convertToSoles(pesos);
        double pesetas = pesosInterface.convertToPesetas(pesos);
        double francs = pesosInterface.convertToFrancs(pesos);

        System.out.println("Resultado de las conversiones:");
        System.out.println("Dollars: " + dollars);
        System.out.println("Bolivares: " + bolivares);
        System.out.println("Soles: " + soles);
        System.out.println("Pesetas: " + pesetas);
        System.out.println("Francs: " + francs);

        scanner.close();
    }
    }
    

