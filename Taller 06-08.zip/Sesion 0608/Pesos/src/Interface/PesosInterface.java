/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

/**
 *
 * @author Ambiente 209-2
 */
public interface PesosInterface {
    double convertToDollars(double pesos);
    double convertToBolivares(double pesos);
    double convertToSoles(double pesos);
    double convertToPesetas(double pesos);
    double convertToFrancs(double pesos);
}
