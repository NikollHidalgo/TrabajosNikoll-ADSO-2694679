/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

import java.util.Scanner;

/**
 *
 * @author Ambiente 209-2
 */
public class FunctionNumeric {
    private Double numero;

    private Double getNumero() {
        return numero;
    }

    private void setNumero(Double numero) {
        this.numero = numero;
    }

    public Double InputNumericScanner(String mensaje) {
        InputNumeric(mensaje, 1);
        return this.getNumero();
    }

    public Double InputNumericJOptionPane(String mensaje) {
        InputNumeric(mensaje, 2);
        return this.getNumero();
    }
    
    private void InputNumeric(String mensaje, int tipo) {
        Boolean validar = false;
        FunctionString fs = new FunctionString();

        //Validar que se ingrese el dato correcto
        while (validar == false) {
            try {
                if(tipo==1){
                    this.setNumero(Double.parseDouble(fs.InputScanner(mensaje)));
                }else{
                    this.setNumero(Double.parseDouble(fs.InputJOptionPane(mensaje)));
                }
                validar = true;
            } catch (Exception e) {
                if (tipo==1) {
                    fs.ShowScanner("Ha ingresado un dato no válido. ");
                }else{
                    fs.ShowJOptionPane("Ha ingresado un dato no válido. ");
                }
            }
        }        
    }
    
    
    public Double InputNumericRangeScanner(String mensaje, Double min, Double max) {
        do {            
            InputNumeric(mensaje,1);
        } while (this.getNumero() < min || this.getNumero() > max);
        
        return this.getNumero();
    }

    public Double IntPositivoNegativo(String  mensaje){
    do {
    InputNumeric(mensaje,1);
    }while (this.getNumero()<=0);
    return this.getNumero();
    }
    
     public Double IntRangoNoRango(String mensaje){
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Ingresa un numero real en el rango [0.0, 100.0]");
        double numeroReal = scanner.nextDouble();
        
        if(numeroReal >= 0.0 && numeroReal<= 100.0){
            System.out.println("Numero valido: " + numeroReal);
        }else{
            System.out.println("El numero debe estar entre 0.0 y 100.0");
        }
    
        System.out.println("Ingresa un numero entero en el rango [1, 100]");
        int numeroEntero = scanner.nextInt();
        
        if(numeroReal >= 0.0 && numeroReal<= 100){
            System.out.println("Numero valido: " + numeroEntero);
        }else{
            System.out.println("El numero debe estar entre 1 y 100");
        }
        return null;
        
    }
}
