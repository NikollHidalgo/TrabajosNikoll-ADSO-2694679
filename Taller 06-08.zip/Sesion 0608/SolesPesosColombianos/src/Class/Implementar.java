/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import Interface.ConvertirSoles;

/**
 *
 * @author User
 */
public class Implementar implements ConvertirSoles{
    private static final double COL_PESO_EXCHANGE_RATE = 3865.0;
    private static final double DOLLAR_EXCHANGE_RATE = 3.8; 
    private static final double BOLIVAR_EXCHANGE_RATE = 400000.0; 
    private static final double PESETA_EXCHANGE_RATE = 0.01; 

    @Override
    public double convertToColombianPesos(double soles) {
        return soles * COL_PESO_EXCHANGE_RATE;
    }

    @Override
    public double convertToDollars(double soles) {
        return soles * DOLLAR_EXCHANGE_RATE;
    }

    @Override
    public double convertToBolivares(double soles) {
        return soles * BOLIVAR_EXCHANGE_RATE;
    }

    @Override
    public double convertToPesetas(double soles) {
        return soles * PESETA_EXCHANGE_RATE;
    }

    @Override
    public double convertToFrancs(double soles) {
        double FRANC_EXCHANGE_RATE = 0;
        return soles * FRANC_EXCHANGE_RATE;
    }
    
}
