/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassSorteo;

import ClassBoleta.Boleta;

/**
 *
 * @author User
 */
public class Sorteo {
    private String numeroGanador;
    private String colorGanador;

    public Sorteo(String numeroGanador, String colorGanador) {
        this.numeroGanador = numeroGanador;
        this.colorGanador = colorGanador;
    }

    public boolean esGanador(Boleta boleta) {
        return boleta.getNumero().equals(numeroGanador) && boleta.getColor().equals(colorGanador);
    }
    
}
