/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassOyente;

import Class.Artista;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class Oyente {
    private String nombre;
    private List<Artista> artistasFavoritos;

    public Oyente(String nombre) {
        this.nombre = nombre;
        this.artistasFavoritos = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public List<Artista> getArtistasFavoritos() {
        return artistasFavoritos;
    }

    public void agregarArtistaFavorito(Artista artista) {
        artistasFavoritos.add(artista);
    }
}
