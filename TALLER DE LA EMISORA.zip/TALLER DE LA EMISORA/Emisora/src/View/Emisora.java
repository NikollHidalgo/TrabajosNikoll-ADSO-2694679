/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;

import Class.Artista;
import ClassBoleta.Boleta;
import ClassOyente.Oyente;
import ClassSorteo.Sorteo;
import ClassVista.Vista;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author User
 */
public class Emisora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Oyente> oyentes = new ArrayList<>();
        Random random = new Random();

        for (int i = 1; i <= 50; i++) {
            String nombreOyente = "Sofia Camila" + i;
            Oyente oyente = new Oyente(nombreOyente);

            //Selección aleatoria de artistas favoritos
            for (int j = 0; j < 3; j++) {
                String nombreArtista = "Bad Bunny" + (random.nextInt(5) + 1);
                Artista artista = new Artista(nombreArtista);
                oyente.agregarArtistaFavorito(artista);
            }

            oyentes.add(oyente);
        }

        // La boleta entregada a cada oyente
        for (Oyente oyente : oyentes) {
            String numeroBoleta = String.valueOf(random.nextInt(100) + 1);
             String colorBoleta = generarColorAleatorio();
            Boleta boleta = new Boleta(numeroBoleta, colorBoleta);

            // Realizar el sorteo de premios
            Sorteo sorteo = new Sorteo("42", "Verde"); // Valores simulados
            if (sorteo.esGanador(boleta)) {
                Vista vista = new Vista();
                vista.mostrarMensaje(oyente.getNombre() + " es el ganador del premio.");
                break;
            }

    }
    
}
        private static String generarColorAleatorio() {
        String[] colores = {"Rojo", "Azul", "Verde", "Amarillo", "Naranja"};
        Random random = new Random();
        return colores[random.nextInt(colores.length)];
    }
     

}

    
