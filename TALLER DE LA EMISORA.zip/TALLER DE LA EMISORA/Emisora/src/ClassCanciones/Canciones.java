/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassCanciones;

import Interface.Normalizacion;

/**
 *
 * @author User
 */
public class Canciones implements Normalizacion {
    private String nombre;

    public Canciones(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String normalizar(String entrada) {
        // Implementa la lógica de normalización de nombres de canciones si es necesario
        return entrada;
    }
}
