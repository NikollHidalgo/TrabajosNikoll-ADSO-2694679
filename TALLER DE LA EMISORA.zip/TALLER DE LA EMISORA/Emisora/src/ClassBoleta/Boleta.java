/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassBoleta;

/**
 *
 * @author User
 */
public class Boleta {
    private String numero;
    private String color;

    public Boleta(String numero, String color) {
        this.numero = numero;
        this.color = color;
    }

    public String getNumero() {
        return numero;
    }

    public String getColor() {
        return color;
    }
    
}
