/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClassEncuesta;

import ClassOyente.Oyente;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class Encuesta {
    private List<Oyente> oyentes;

    public Encuesta() {
        oyentes = new ArrayList<>();
    }

    public void agregarOyente(Oyente oyente) {
        oyentes.add(oyente);
    }
}
