/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import Interface.Normalizacion;

/**
 *
 * @author User
 */
public class Artista implements Normalizacion {
    private String nombre;

    public Artista(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String normalizar(String entrada) {
        // Implementa la lógica de normalización de nombres de artistas si es necesario
        return entrada;
    }
}
