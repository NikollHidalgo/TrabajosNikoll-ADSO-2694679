/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Porcentaje;

/**
 *
 * @author User
 */
public class Inversion {
    public static void main(String[] args){
        
        double inversionPersona1 = 7000.0;
        double inversionPersona2 = 4000.0;
        double inversionPersona3 = 10000.0;
        
        double totalInvertido = inversionPersona1 + inversionPersona2 + inversionPersona3;
        
        double porcentajePersona1 = (inversionPersona1 / totalInvertido);
        double porcentajePersona2 = (inversionPersona2 / totalInvertido);
        double porcentajePersona3 = (inversionPersona3 / totalInvertido);
        
        System.out.println("Persona 1 invierte el " + porcentajePersona1 + "%");
        System.out.println("Persona 2 invierte el " + porcentajePersona2 + "%");
        System.out.println("Persona 3 invierte el " + porcentajePersona3 + "%");
        System.out.println("Total invertido: " + totalInvertido);
    } 
    
}
