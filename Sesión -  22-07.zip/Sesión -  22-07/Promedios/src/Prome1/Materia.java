/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prome1;

/**
 *
 * @author User
 */
public class Materia {
    
    private double nombre;
    private double examen;
    private double promedioTareas;
    private int numeroTareas;

    public Materia(double nombre, double examen, double promedioTareas, int numeroTareas) {
        this.nombre = nombre;
        this.examen = examen;
        this.promedioTareas = promedioTareas;
        this.numeroTareas = numeroTareas;
    }

    public double calcularPromedio() {
        return examen * 0.9 + promedioTareas * 0.1;
    }
    
    public double getExamen() {
        return examen;
    }

    public double getPromedioTareas() {
        return promedioTareas;
    }

    public int getNumeroTareas() {
        return numeroTareas;
    }
}
