/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prome1;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class View {
    public static void main(String[] args) {
    
        Scanner scanner = new Scanner(System.in);

        // Ingresar calificaciones para Matemáticas
        System.out.println("Ingrese calificación del examen de Matemáticas (0-100):");
        double examenMatematicas = scanner.nextDouble();

        System.out.println("Ingrese calificación del promedio de tareas de Matemáticas (0-100):");
        double promedioTareasMatematicas = scanner.nextDouble();

        // Ingresar calificaciones para Física
        System.out.println("Ingrese calificación del examen de Física (0-100):");
        double examenFisica = scanner.nextDouble();
        
        System.out.println("Ingrese calificación del promedio de tareas de Física (0-100):");
        double promedioTareasFisica = scanner.nextDouble();

        // Ingresar calificaciones para Química
        System.out.println("Ingrese calificación del examen de Química (0-100):");
        double examenQuimica = scanner.nextDouble();

        System.out.println("Ingrese calificación del promedio de tareas de Química (0-100):");
        double promedioTareasQuimica = scanner.nextDouble();

        scanner.close();
}
}
