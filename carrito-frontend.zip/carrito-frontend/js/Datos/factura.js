


let facturaIdSeleccionada = null; // Variable global para almacenar el ID de la factura seleccionada

let detallesFactura = []; // Variable global para almacenar los detalles de la factura
let valorTotalFactura = 0; 

console.log(detallesFactura);

function agregarDetalle() {
  // Obtener valores de los campos

  const producto = parseInt($('#Producto_id').val())
  const cantidad = parseInt($('#cantidad').val());
  const valorUnitario = parseFloat($('#valor_unitario').val());

  // Calcular el valor total del detalle
  const valorTotalDetalle = cantidad * valorUnitario;

  // Agregar detalle a la lista de detalles
  detallesFactura.push({
    'productoId': {
      'id': producto
    },
    'estado':parseInt($('#estado').val()),
    'cantidad': cantidad,
    'valorPagar': parseFloat($('#valor_unitario').val()),
    // Otros campos del detalle si los hay
  });
  console.log(detallesFactura)

  // Actualizar el valor total de la factura
 //valorTotalFactura += valorTotalDetalle;

  // Actualizar campo de valor total en el formulario
  $('#valor_total').val(valorTotalDetalle);
}

//ESTE MÉTODO ES PARA GUARDAR
function save() {
  // Construir el objeto data
  var data_factura = {
    'estado': parseInt($('#estado').val()),
    'codigo': $('#codigo').val(),
    'fecha': $('#fecha').val(),
    'valorTotal': parseFloat($('#valor_total').val()),
    'clienteId': {
      'id': parseInt($('#cliente_id').val())
    }
  };
  
  $.ajax({
    url: 'http://localhost:9000/v1/api/factura',
    method: 'POST',
    dataType: 'json',
    contentType: 'application/json',
    data: JSON.stringify(data_factura),
    success: function (facturaCreada) {
      var facturaIdCreada = facturaCreada.id;
  
      // Iterar sobre cada detalle y enviarlos uno por uno
      detallesFactura.forEach(function (detalle) {
        detalle.facturaId = {
          'id': facturaIdCreada
        };
  
        var data_detalle = {
          'cantidad': detalle.cantidad,
          'valorPagar': detalle.valorPagar,
          'productoId': detalle.productoId,
          'facturaId': detalle.facturaId,
          'estado': detalle.estado
          // Agrega otros campos según sea necesario en tu objeto JSON
        };
  
        $.ajax({
          url: 'http://localhost:9000/v1/api/DetalleFactura',
          method: 'POST',
          dataType: 'json',
          contentType: 'application/json',
          data: JSON.stringify(data_detalle),
          success: function (data) {
            console.log("Detalle agregado con éxito:", data);
            // Si necesitas alguna lógica adicional después de agregar cada detalle, aquí puedes añadirla
          },
          error: function (error) {
            console.error('Error al agregar el detalle:', error);
          }
        });
      });
  
      // Resto del código después de agregar los detalles
    },
    error: function (error) {
      console.error('Error en la solicitud:', error);
    }
  });
  
}
function operation() {
 


  $('#cantidad, #valor_unitario').on('input', function () {
    
    var cantidad = parseFloat($('#cantidad').val()) || 0;
    var valorUnitario = parseFloat($('#valor_unitario').val()) || 0;

    
    var valorTotal = cantidad * valorUnitario;

    
    $('#valor_total').val(valorTotal.toFixed(2)); // Puedes ajustar la precisión según tus necesidades
 });
}




// Llamar a la función y mostrar el resultado en la consola
var resultadoOperacion = operation();
console.log(resultadoOperacion);

  //ESTE MÉTODO ES PARA ACTUALIZAR
  
  function update() {
    // Construir el objeto data
    var data = {
      'codigo': $('#codigo').val(),
      'fecha': $('#fecha').val(),
      'cliente_id': $('#cliente_id').val(),
      'Producto_id': $('#Producto_id').val(),
      'estado': parseInt($('#estado').val()),
    };
    var id = $("#id").val();
    var jsonData = JSON.stringify(data);
    $.ajax({
      url: 'http://localhost:9000/v1/api/factura/' +id,
      data: jsonData,
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      }
    }).done(function (result) {
      alert("Registro actualizado con éxito");
      loadData();
      clearData();
  
      //actualzar boton
      var btnAgregar = $('button[name="btnAgregar"]');
      btnAgregar.text('Agregar');
      btnAgregar.attr('onclick', 'save()');
    })
  }




function loadDataP() {
  $.ajax({
    url: 'http://localhost:9000/v1/api/producto',
    method: 'GET',
    dataType: 'json',
    success: function (data) {
      console.log(data)
      var html = '';

      data.forEach(function (item) {
        
      });

      $('#resultData').html(html);
    },
    error: function (error) {
      // Función que se ejecuta si hay un error en la solicitud
      console.error('Error en la solicitud:', error);
    }
    });
  }

function loadData() {
  $.ajax({
    url: 'http://localhost:9000/v1/api/DetalleFactura',
    method: 'GET',
    dataType: 'json',
    success: function (data) {
      console.log(data)
      var html = '';

      data.forEach(function (item) {
        // Construir el HTML para cada objeto
        html += `<tr>
        <td>`+ item.facturaId.clienteId.nombre + `</td>
               <td>`+ item.facturaId.codigo + `</td>
                <td>`+ item.productoId.nombre + `</td>
                <td>`+ item.valorPagar + `</td>
                <td>`+ item.cantidad + `</td>
                <td>`+ item.facturaId.valorTotal + `</td>

                <td>`+ (item.estado == true ? 'Activio' : 'Inactivo') + `</td>
                <th><img src="./asset/icon/pencil-square.svg" alt="" onclick="findById(`+ item.id + `)"></th>
                <th><img src="./asset/icon/trash3.svg" alt="" onclick="deleteById(`+ item.id + `)"></th>
            </tr>`;
      });

      $('#resultData').html(html);
    },
    error: function (error) {
      // Función que se ejecuta si hay un error en la solicitud
      console.error('Error en la solicitud:', error);
    }
  });
}

function loadDataC() {
  $.ajax({
    url: 'http://localhost:9000/v1/api/cliente',
    method: 'GET',
    dataType: 'json',
    success: function (data) {
      console.log(data)
      var html = '';

      data.forEach(function (item) {
        // Construir el HTML para cada objeto
        
      });

      $('#resultData').html(html);
    },
    error: function (error) {
      // Función que se ejecuta si hay un error en la solicitud
      console.error('Error en la solicitud:', error);
    }
    });
  }
  //ESTE MÉTODO MUESTRA LOS DATOS DE CLIENTES
  function selectCliente() {
    $.ajax({
      url: 'http://localhost:9000/v1/api/cliente',
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        var html = '';
  
        data.forEach(function (item) {
          // Construir el HTML para cada objeto
          html += `
                  <option value="`+item.id+`">`+ item.nombre + `</option>;
                  `
        });
  
        $('#cliente_id').html(html);
      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  }

  function selectProducto() {
    $.ajax({
      url: 'http://localhost:9000/v1/api/producto',
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        var html = '';
        console.log(data)
  
        data.forEach(function (item) {
          // Construir el HTML para cada objeto
          html += `
                  <option value="`+item.id+`">`+ item.nombre + `</option>;
                  `
        });
  
        $('#Producto_id').html(html);
      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  }
  
  //ESTE MÉTODO LLENA LOS CAMPOS DE LOS REGISTROS SELECIONADOS
  
  function findByIdFactura(id) {
    $.ajax({
      url: 'http://localhost:9000/v1/api/factura/' + id,
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        $('#id').val(data.id);
        $('#codigo').val(data.codigo);
        $('#Producto_id').val(data.Producto_id);
        $('#fecha').val(data.fecha);
        $('#cliente_id').val(data.cliente_id);
        $('#estado').val(data.estado == true ? 1 : 0);
  
        //Cambiar boton.
        var btnAgregar = $('button[name="btnAgregar"]');
        btnAgregar.text('Actualizar');
        btnAgregar.attr('onclick', 'update()');
      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  }

  
  function findByIdDetalle(id) {
    $.ajax({
      url: 'http://localhost:9000/v1/api/DetalleFactura/' + id,
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        $('#id').val(data.id);
      
        $('#cantidad').val(data.cantidad);
        $('#valor_unitario').val(data.valorPagar);
       
        $('#estado').val(data.estado == true ? 1 : 0);
  
        //Cambiar boton.
        var btnAgregar = $('button[name="btnAgregar"]');
        btnAgregar.text('Actualizar');
        btnAgregar.attr('onclick', 'update()');
      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  }
  
  //estas son las funciones de eliminar ES PARA ELIMINAR
  
  function deleteByIdDetalle(id) {
    $.ajax({
      url: 'http://localhost:9000/v1/api/DetalleFactura/' + id,
      method: "delete",
      headers: {
        "Content-Type": "application/json"
      }
    }).done(function (result) {
      alert("Registro eliminado con éxito");
      cargarDatos();
      clearData();
    })
  }

  function deleteByIdFactura(id) {
    $.ajax({
      url: 'http://localhost:9000/v1/api/factura/' + id,
      method: "delete",
      headers: {
        "Content-Type": "application/json"
      }
    }).done(function (result) {
      alert("Registro eliminado con éxito");
      cargarDatos();
      clearData();
    })
  }
  
  //ESTE MÉTODO ES PARA LIMPIAR 
  
  function clearData() {
    //$('#id').val('');
    //$('#codigo').val('');
    $('#Producto_id').val('');
    //$('#cliente_id').val('');
    //$('#fecha  ').val('');
    //$('#estado').val('');
    $('#valorTotal').val('');
    $('#cantidad').val('');
    $('#valor_unitario').val('');
    
  }
// dos eventos onclik 
  function saveAndOperate() {
    save();      // Llamando a la función save()
    operation(); // Llamando a la función operation()
}


// funcion que maneja la logicaa de consultar



function cargarDatos() {
  var tipoSeleccionado = $('#tipoDatos').val();
  var tituloTabla = $('#tituloTabla');

  // Limpiar los títulos actuales
  tituloTabla.empty();

  if (tipoSeleccionado === 'factura') {
    tituloTabla.append('<th>Codigo</th>'); 
    tituloTabla.append('<th>Fecha</th>'); 
    tituloTabla.append('<th>Valor total</th>');
    tituloTabla.append('<th>cliente</th>');
    tituloTabla.append('<th> Estado</th>');
    tituloTabla.append('<th colspan="2">Acciones</th>');
    cargarDatosFactura();
  } else if (tipoSeleccionado === 'detalle') {
    tituloTabla.append('<th>Producto</th>');
    tituloTabla.append('<th>Factura codigo</th>');
    tituloTabla.append('<th>Producto</th>');
    tituloTabla.append('<th>Valor unitario</th>');
    tituloTabla.append('<th>Cantidad</th>');
    tituloTabla.append('<th>Valor Total Factura</th>');
    tituloTabla.append('<th> Estado</th>');
    tituloTabla.append('<th colspan="2">Acciones</th>');
    cargarDatosDetalle();
  }

  // Inicializar DataTables fuera de los condicionales

  // Inicializar DataTables fuera de los condicionales
  $('#resultData').DataTable({
    "paging": true,
    "lengthChange": false,
    "pageLength": 5, // Mostrar solo 5 registros por página
    // Otras opciones según tu preferencia
  });

  // Evento click para el paginador
  
  $(document).on('click', '.pagination li', function() {
    var pageIndex = $(this).text();
    $('#resultData').DataTable().page(pageIndex - 1).draw(false);
  });
}


function cargarDatosFactura() {

  
    $.ajax({
      url: 'http://localhost:9000/v1/api/factura',
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        var html = '';
  
        data.forEach(function (item) {
          // Construir el HTML para cada objeto
          html += `<tr>
                  <td>`+ item.codigo + `</td>
                  <td>`+ item.fecha + `</td>
                  <td>`+ item.valorTotal + `</td>
                  <td>`+ item.clienteId.nombre + `</td>
                  <td>`+ (item.estado == true ? 'Activio' : 'Inactivo') + `</td>
                  <th><img src="./asset/icon/pencil-square.svg" alt="" onclick="findByIdFactura(`+ item.id + `)"></th>
                  <th><img src="./asset/icon/trash3.svg" alt="" onclick="deleteByIdFactura(`+ item.id + `)"></th>
              </tr>`;
        });
  
        $('#resultData').html(html);
      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  
}

function cargarDatosDetalle() {
  
 

  $.ajax({
    url: 'http://localhost:9000/v1/api/DetalleFactura',
    method: 'GET',
    dataType: 'json',
    success: function (data) {
      console.log(data)
      var html = '';

      data.forEach(function (item) {
        // Construir el HTML para cada objeto
        html += `<tr>
        <td>`+ item.facturaId.clienteId.nombre + `</td>
               <td>`+ item.facturaId.codigo + `</td>
                <td>`+ item.productoId.nombre + `</td>
                <td>`+ item.valorPagar + `</td>
                <td>`+ item.cantidad + `</td>
                <td>`+ item.facturaId.valorTotal + `</td>

                <td>`+ (item.estado == true ? 'Activio' : 'Inactivo') + `</td>
                <th><img src="./asset/icon/pencil-square.svg" alt="" onclick="findByIdDetalle(`+ item.id + `)"></th>
                <th><img src="./asset/icon/trash3.svg" alt="" onclick="deleteByIdDetalle(`+ item.id + `)"></th>
            </tr>`;
      });

      $('#resultData').html(html);
    },
    error: function (error) {
      // Función que se ejecuta si hay un error en la solicitud
      console.error('Error en la solicitud:', error);
    }
  });

}
