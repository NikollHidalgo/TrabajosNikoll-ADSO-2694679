/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arearectangulo;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AreaRectangulo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //La longitud de la base y la altura
        System.out.print("Ingresa la longitud de la base del rectángulo: ");
        double base = scanner.nextDouble();
        
        System.out.print("Ingresa la altura del rectángulo: ");
        double altura = scanner.nextDouble();
        
        //El area del rectángulo
        double area = base * altura;
        
        //El resultado
        System.out.println("El área del rectángulo es: " + area);
        
        //Cerrar el Scanner
        scanner.close();
       
    }
}
