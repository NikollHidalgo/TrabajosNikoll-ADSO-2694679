/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.volumencubo;

/**
 *
 * @author User
 */
public class VolumenCubo {
    
    public static double calcularVolumenCubo(double base, double profundidad,
            double altura){
       
        double volumen = base * profundidad * altura;
        return volumen;

    }

    public static void main(String[] args) {
        
        double base = 12;
        double profundidad = 8;
        double altura = 30;
        
        double volumen = calcularVolumenCubo(base, profundidad, altura);
        
        System.out.println("El volumen del prisma rectangular es: " + volumen);
        
    }
}
