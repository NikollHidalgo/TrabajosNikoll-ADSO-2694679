/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.areacircunferencia;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AreaCircunferencia {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //El radio
        System.out.print("Ingresa el radio de la circunsferencia: ");
        double radio  = scanner.nextDouble();
        
        //Area de la circunferencia
        double area = Math.PI * Math.pow(radio, 2);
        
        //El resultado
        System.out.println("El area de la circunferencia es: " + area);
        
        //Cerrar el scanner
        scanner.close();
    }
}
