/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.areacuadrado;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AreaCuadrado {

    public static void main(String[] args) {
        Scanner scanner = new swcanner(System.in);
        
        //La longitud del lado
        System.out.print("Ingresa la longitud del lado del cuadrado: ");
        double lado = scanner.nextDouble();
        
        
        //El area del cuadrado
        double area = lado * lado;
        
        //El resultado
        System.out.println("El área del cuadrado es: " + area);
        
        //Cerrar el scanner
        scanner.close();
    }
}
