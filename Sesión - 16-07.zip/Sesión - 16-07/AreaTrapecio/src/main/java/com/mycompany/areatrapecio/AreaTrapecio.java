/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.areatrapecio;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AreaTrapecio {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //La longitud de las bases y la altura al usuario
        System.out.print("Ingresa la longitud de la base 1 del trapecio: ");
        double base1 = scanner.nextDouble();
        
        System.out.print("Ingresa la longitud de la base 2 del trapecio: ");
        double base2 = scanner.nextDouble();
        
        System.out.print("Ingresa la altura del trapecio: ");
        double altura = scanner.nextDouble();
        
        //El área del trapecio
        double area = ((base1 + base2) * altura) / 2;
        
        //El resultado
        System.out.println("El área del trapecio es: " + area);
        
        //Cerrar el scanner
        scanner.close();
    }
}
