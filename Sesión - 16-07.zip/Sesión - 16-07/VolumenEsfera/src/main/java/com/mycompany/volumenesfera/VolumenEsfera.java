/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.volumenesfera;

/**
 *
 * @author User
 */
public class VolumenEsfera {
    
    public static double calcularVolumenEsfera(double radio){
        double volumen = (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);
        return volumen;
    }

    public static void main(String[] args) {
        double radio = 6; 
        double volumen = calcularVolumenEsfera(radio);
        
        System.out.println("El volumen de la esfera con radio: " + radio);
        
    }
}
