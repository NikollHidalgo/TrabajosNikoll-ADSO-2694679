/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.volumencilindro;

/**
 *
 * @author User
 */
public class VolumenCilindro {
    
    public static double calcularVolumenCilindro(double radio, double altura){
        double areaBase = Math.PI * Math.pow(radio, 2);
        double volumen = areaBase * altura;
        return volumen;
    }

    public static void main(String[] args) {
        double radio = 20;
        double altura = 10;
        
        double volumen = calcularVolumenCilindro(radio, altura);
        
        System.out.println("El volumen del cilindro con radio " + radio + " y altura " + altura + " es: " + volumen);
        
        
    }
}
