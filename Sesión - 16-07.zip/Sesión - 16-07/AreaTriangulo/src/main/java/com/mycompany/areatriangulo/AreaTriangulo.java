/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.areatriangulo;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AreaTriangulo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //La longitud de la base y la altura 
        System.out.print("Ingresa la longitud de la base del triangulo: ");
        double base = scanner.nextDouble();
        
        System.out.print("Ingresa la altura del triangulo: ");
        double altura = scanner.nextDouble();
        
        //El area del triangulo
        double area = (base * altura) / 2;
        
        //El resultado
        System.out.println("El área del triángulo es: " + area);
        
        //Cerrar el Scanner
        scanner.close();
        
    }
}
