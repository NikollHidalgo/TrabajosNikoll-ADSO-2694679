/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arearombo;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class AreaRombo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //La longitud de las diagonales
        System.out.print("Ingresa la longitud de la diagonal 1 del rombo: ");
        double diagonal1 = scanner.nextDouble();
        
        System.out.print("Ingresa la longitud de la diagonal 2 del rombo: ");
        double diagonal2 = scanner.nextDouble();
        
        //El área del rombo
        double area = (diagonal1 * diagonal2) / 2;
        
        //El resultado
        System.out.println("El area del rombo es: " + area);
        
        //Cerrar el scanner
        scanner.close();
        
        
    }
}
