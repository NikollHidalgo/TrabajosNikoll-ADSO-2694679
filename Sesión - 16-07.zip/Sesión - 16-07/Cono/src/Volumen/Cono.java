/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Volumen;

/**
 *
 * @author User
 */
public class Cono {
    public static void main (String[] argas){
        
        double radio = 6.0;
        double altura = 10.0;  
        
        double volumen = (1.0 / 3.0)* Math.PI * Math.pow(radio, 3) * altura;
        
        System.out.println("El volumen del cono es: " + volumen);
    }
    
}
