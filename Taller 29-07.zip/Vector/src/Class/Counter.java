/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import InterfaceCounter.CounterView;

/**
 *
 * @author User
 */
public class Counter implements CounterView {
    private double[] data;
    
    public Counter(double[] data){
        this.data = data;
    }
    
    @Override
    public void count(){
        int positiveCount = 0;
        int negativeCount = 0;
        
        for(double value : data){
            if (value > 0){
                positiveCount++;
            } else if (value < 0){
                negativeCount++;
            }
        }
        
        System.out.println("Cantidad de valores positivos: " + positiveCount);
        System.out.println("Cantidad de valores negativos: " + negativeCount);
                
    }
   
}
