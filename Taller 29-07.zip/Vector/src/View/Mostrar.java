/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;

import Class.Counter;
import Definitiva.Vector;

/**
 *
 * @author User
 */
public class Mostrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double[] vectorData = {2, 3, 5, 1, 6, -2};
        Vector vector = new Vector(vectorData);
        vector.showHorizontal();
        
        Counter counter = new Counter(vectorData);
        counter.count();
    }
    
}
