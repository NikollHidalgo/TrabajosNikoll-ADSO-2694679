/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Definitiva;

import InterfaceVector.VectorView;

/**
 *
 * @author User
 */
public class Vector implements VectorView{
    private double[] data;
    
    public Vector(double[] data){
        this.data = data;
    }
    
    @Override
    public void showHorizontal(){
        for (double value : data){
            System.out.print(value + " ");
        }
        System.out.println();
                
    }
}
