/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class NumeroReal {
    private ArrayList<Double> numeros;
    
    public NumeroReal(){
        numeros = new ArrayList<>();
    }
    
    public void leerNumeros(){
        Scanner scanner = new Scanner (System.in);
        boolean continuar = true;
        do{
            System.out.print("Ingresa un número real (o escriba 'fin' para finalizar): ");
            String entrada = scanner.nextLine();
            
            if(entrada.equalsIgnoreCase("fin")){
                continuar = false;
            } else{
                try{
                    double numero = Double.parseDouble(entrada);
                    numeros.add(numero);
                } catch (NumberFormatException e){
                    System.out.println("Entrada inválida. Intenta nuevamente. ");  
                }
            }
        }while (continuar);
    }
    
    public int contarpares(){
        int pares = 0;
        for (double numero : numeros){
            if (numero % 2 == 0){
                pares++;
            }
        }
        return pares;
    }
    
    public int contarImpares(){
        int impares = 0;
        for(double numero : numeros){
            if(numero % 2 != 0){
                impares++;
            }
        }
        return impares;
    }
    
    public int contarNegativos(){
        int negativos = 0;
        for (double numero : numeros){
            if (numero < 0){
                negativos++;
            }
        }
        return negativos;
    }
    
    public int contarCeros(){
        int ceros = 0;
        for(double numero : numeros){
            if(numero == 0){
                ceros++;
            }
        }
        return ceros;
    }
    
    public int contarPositivos(){
        int positivos = 0;
        for(double numero : numeros){
            if(numero > 0){
                positivos++;
            }
        }
        return positivos;
    }
    
    public double otenerMaximo(){
        if(numeros.isEmpty()){
            return Double.NaN;
        }
        double maximo = numeros.get(0);
        for (double numero : numeros){
            if(numero > maximo){
                maximo = numero;
            }
        }
        return maximo;
    }
    
    public double obtenerMinimo(){
        if(numeros.isEmpty()){
            return Double.NaN;
        }
        double minimo = numeros.get(0);
        for (double numero : numeros){
            if (numero < minimo){
                minimo = numero;
            }
        }
        return minimo;
    }
    
}
