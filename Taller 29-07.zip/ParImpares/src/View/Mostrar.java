/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;
import Class.NumeroReal;

/**
 *
 * @author User
 */
public class Mostrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NumeroReal numeroReal = new NumeroReal();
        numeroReal.leerNumeros();
        
        int pares = numeroReal.contarpares();
        int impares = numeroReal.contarImpares();
        int negativos = numeroReal.contarNegativos();
        int ceros = numeroReal.contarCeros();
        int positivos = numeroReal.contarPositivos();
        double maximo = numeroReal.otenerMaximo();
        double minimo = numeroReal.obtenerMinimo();
        
        System.out.println("Resultados: ");
        System.out.println("Cantidad de números pares: " + pares);
        System.out.println("Cantidad de números impares: " + impares);
        System.out.println("Cantidad de números negativos: " + negativos);
        System.out.println("Cantidad de ceros (nulos): " + ceros);
        System.out.println("Cantidad de números positivos: " + positivos);
        System.out.println("Número más alto: " + maximo);
        System.out.println("Número más bajo: " + minimo);
        
    }
    
}
