package com.sena.servicesecurity.Enums;

public enum NomeclaturaEnum {
	
	calle,
	carrera,
	transversal,
	bis
}
