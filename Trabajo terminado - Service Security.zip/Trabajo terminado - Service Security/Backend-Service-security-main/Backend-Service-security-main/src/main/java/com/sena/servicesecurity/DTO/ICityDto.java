package com.sena.servicesecurity.DTO;

public interface ICityDto extends IGenericDto {

	
	String getName_city();
	String getCode_city();
	String getDepartment();
}
