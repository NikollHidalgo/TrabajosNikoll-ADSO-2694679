package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.Company;

public interface ICompanyService extends IBaseService<Company>{

}
