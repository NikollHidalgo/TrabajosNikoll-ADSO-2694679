package com.sena.servicesecurity.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.Company;

@Repository
public interface ICompanyRepository extends IBaseRepository<Company, Long>{

}
