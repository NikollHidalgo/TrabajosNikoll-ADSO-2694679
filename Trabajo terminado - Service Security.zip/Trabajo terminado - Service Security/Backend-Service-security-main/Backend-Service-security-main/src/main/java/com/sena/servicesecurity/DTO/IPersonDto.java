package com.sena.servicesecurity.DTO;

public interface IPersonDto extends IGenericDto{

	String getType_document();
    void setType_document(String type_document);
    String getCode();
    void setCode(String code);
    String getDocument();
    void setDocument(String document);
	String getPerson();
	
	
}
