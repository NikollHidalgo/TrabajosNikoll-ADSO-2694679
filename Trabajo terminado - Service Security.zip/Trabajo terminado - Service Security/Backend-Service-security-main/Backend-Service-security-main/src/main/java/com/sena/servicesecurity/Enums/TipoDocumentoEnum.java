package com.sena.servicesecurity.Enums;

public enum TipoDocumentoEnum {
	DNI,
	CC,
	TI,
	PS,
	RC
}
