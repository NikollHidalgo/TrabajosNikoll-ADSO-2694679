package com.sena.servicesecurity.DTO;

public interface IEmployedDto extends IGenericDto{
	
	String getCode();
	String getPerson();
	String getPosition();
	String getCompany();
}
