/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class CuadradoMayor {
    class Cuadrado{
    private double numero;
    private double cuadrado;

    public Cuadrado(double numero){
    this.numero=numero;
    }

    public void calcularCuadrado(){
    cuadrado =numero*numero;
    System.out.println("El cuadrado del numero es:"+cuadrado);
    }
    
    public void numeromayor() {
    double cuadro = numero * numero;
    if (cuadro > 5000) {
    System.out.println("El cuadrado del número es mayor a 5000.");
    } 
    else {
    System.out.println("El cuadrado del número no es mayor a 5000.");
        }
    }
}
    
}
