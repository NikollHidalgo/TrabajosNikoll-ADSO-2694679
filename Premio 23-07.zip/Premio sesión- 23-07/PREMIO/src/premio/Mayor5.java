/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class Mayor5 {
    
    class Mayor200{
    private double numero;

    public Mayor200(double numero) {
    this.numero = numero;
    }

    public double mayor() {
    if (numero > 200) {
    System.out.println("El número es mayor a 200.");
    } 
    else {
    System.out.println("El número no es mayor a 200.");
    }
    return numero;
    }
}   
}
