/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class RangoParImpar {
    private int numero;

    public RangoParImpar(int numero){
    this.numero=numero;
    }

    public boolean SolucionRango(){
    return (numero>=200&& numero<=300);
    }

    public double Solucion(){
    //Se llama la información de Solucion Rango.
    if (SolucionRango()) {
    System.out.println("Esta en el rango de 200--300");
    return numero;
    } 
    else {
    System.out.println("No esta en el rango de 200--300");
            return -numero;
        }
    }
    
    public boolean Entero(int numero){
    return numero%2==0;
    }

    public void SolucionTodo(){
    if (Entero(numero)){
    System.out.println(numero+" Es un numero par");
    }
    else{
    System.out.println(numero+" Es un numero Impar");
    }
}
}
    

