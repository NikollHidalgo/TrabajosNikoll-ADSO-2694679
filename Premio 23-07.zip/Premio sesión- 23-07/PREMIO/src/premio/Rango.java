/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class Rango {
    private double numero;
    
    public Rango(double numero){
    this.numero=numero;
    }
    
    public boolean SolucionRango(){
    return (numero>=50&& numero<=100);

    }
    
    public double Solucion(){
   //Se llama la informacion de solución rango.
    if (SolucionRango()) {
    System.out.println("Esta en el rango de 50--100");
    return numero;
    } 
    else {
    System.out.println("No esta en el rango de 50--100");
    return -numero;
    }
    }

   
}
