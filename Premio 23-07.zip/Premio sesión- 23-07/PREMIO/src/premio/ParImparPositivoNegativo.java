/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class ParImparPositivoNegativo {
    private int numero;
    
    public ParImparPositivoNegativo(int numero){
    this.numero=numero;
    }

    public double PositivoNegativo(){
    if (numero>=0){
    System.out.println(numero+" Es positivo");
    return numero;
    }
    else{
    System.out.println(numero+"  Es negativo");
    return numero;
    }
    
}
    
    public boolean Entero(int numero){
    return numero%2==0;
    }

    public void SolucionTodo(){
    if (Entero(numero)){
    System.out.println(numero+" Es un numero par");
    }
    else{
    System.out.println(numero+" Es un numero Impar");
    }
}
}
