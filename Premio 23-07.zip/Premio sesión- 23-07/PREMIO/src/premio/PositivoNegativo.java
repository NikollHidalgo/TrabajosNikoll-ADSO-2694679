/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class PositivoNegativo {
    private double numero;
    
    public PositivoNegativo(double numero){
    this.numero=numero;
    }
    
    public double ValorNumero(){
    if (numero>=0){
    System.out.println("El numero es positivo");
    return numero;
    }else{
    System.out.println("El numero es negativo");
    return numero;
    }
    }
    }
    

