/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class ValorAbsoluto {
    class Adsoluto{
    private double numero;
    
    public Adsoluto(double numero){
    this.numero=numero;
    }
    
    public double ValorAdsoluto(){
    if (numero>=0){
    return numero;
    }
    else{
    return -numero;
    }
   }
}
}
