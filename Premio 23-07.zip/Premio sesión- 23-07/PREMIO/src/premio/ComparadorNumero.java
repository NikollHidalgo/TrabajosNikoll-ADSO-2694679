/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premio;

/**
 *
 * @author SENA
 */
public class ComparadorNumero {
    private int num1;
    private int num2;
    
    public void compararNumeros(int num1, int num2) {
    if (num1 > num2) {
    System.out.println(num1 + " es mayor que " + num2);
    System.out.println(num2 + " es menor que " + num1);
    } 
    else if (num1 < num2) {
    System.out.println(num2 + " es mayor que " + num1);
    System.out.println(num1 + " es menor que " + num2);
    } 
    else {
    System.out.println(num1 + " y " + num2 + " son iguales.");
    }
    }
    
}
